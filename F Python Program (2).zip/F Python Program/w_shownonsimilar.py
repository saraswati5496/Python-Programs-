#code for showing differences from two different files CRDEV & QA2 ..it will show output in different file path, path that is given by user.

import pandas as pd
import numpy as np

df_CRDEV = pd.read_excel(r'F:\Python\conv_export\xlsx4\CRDEV_EXPORT_DOWNLOAD.xlsx')
df_QA2 = pd.read_excel(r'F:\Python\conv_export\xlsx4\QA2_EXPORT_DOWNLOAD.xlsx')

comparevalues = df_CRDEV.values == df_QA2.values

#print(comparevalues)

rows,cols = np.where(comparevalues==False)
for item in zip(rows,cols):
    df_CRDEV.iloc[item[0],item[1]] = '{} --> {} '.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])
     

rows,cols = np.where(comparevalues==True)
for item in zip(rows,cols):
    df_CRDEV.iloc[item[0],item[1]] = 'TRUE'.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])


df_CRDEV.to_excel(r'F:\Python\conv_export\xlsx4\output.xlsx', index=False, header=True)

