import cx_Oracle
import os

# Connect to the Oracle database

conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')

# Define the ID for which you want to download the XSLT files
#id_value = 1 or 4

# Define the query to select the XSLT NCLOB files and their names for the given ID from the database table
#query = f"SELECT xslt_file, xslt_file_name FROM table_name WHERE id = {id_value}"
#query = f"SELECT XSL_FO, XSL_FO_FILENAME FROM tbli_form_template_version WHERE form_template_id = {id_value} AND XSL_FO IS NOT NULL"
query = f"SELECT XSL_FO, XSL_FO_FILENAME FROM tbli_form_template_version WHERE form_template_id in (21332)"
# Execute the query
cursor = conn.cursor()
cursor.execute(query)


# Create a directory to save the XSLT files if it doesn't exist
if not os.path.exists('F:\Python\XSLT_download22'):
    os.makedirs('F:\Python\XSLT_download22')

# Iterate over the query result
for row in cursor:
    # Extract the XSLT NCLOB file and its name
    XSL_FO = row[0].read()
    XSL_FO_FILENAME = row[1]
    
    # Save the XSLT NCLOB file with its respective name to the 'xslt_files' directory, if the name is not None
    if XSL_FO_FILENAME:
        file_path = os.path.join('F:\Python\XSLT_download22', XSL_FO_FILENAME)
        with open(file_path, 'wb') as f:
            f.write(XSL_FO.encode('utf-8'))
