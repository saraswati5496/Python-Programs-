# code for displaying data from excel sheets

from openpyxl import load_workbook
import pandas as pd
import numpy as np
import os
import re
#from xlsxwriter import Workbook


wb = load_workbook(r'F:/Python/conv_export/xlsx/multiple_sheet.xlsx')

sheet = wb.active

# Access all cells from A1 to D11
for row in sheet["A1:D11"]:
    print ([x.value for x in row])



#df.compare(excelWriter)
#print(df.equals(df2))





