from itertools import zip_longest
import xlrd
import pandas as pd
import numpy as np
import os 
import re
from openpyxl import load_workbook
# pip install openpyxl, pandas, numpy

rb1 = xlrd.open_workbook(r'F:\Python\conv_export\xlsx\CRDEV_EXPORT_DOWNLOAD.xlsx')
rb2 = xlrd.open_workbook(r'F:\Python\conv_export\xlsx\QA2_EXPORT_DOWNLOAD.xlsx')

CRDEV = rb1.sheet_by_index(0)
QA2 = rb2.sheet_by_index(0)

for rownum in range(max(CRDEV.nrows, QA2.nrows)):
    if rownum < CRDEV.nrows:
        row_rb1 = CRDEV.row_values(rownum)
        row_rb2 = QA2.row_values(rownum)

        for colnum, (c1, c2) in enumerate(zip_longest(row_rb1, row_rb2)):
            if c1 != c2:
                print("Row {} Col {} - {} != {}".format(rownum+1, colnum+1, c1, c2))
    else:
        print("Row {} missing".format(rownum+1))