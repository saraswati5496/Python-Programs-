#code for comparing and showing differences for different excel sheets.. it will create excel sheet and will show difference in that 

import pandas as pd
import numpy as np
from openpyxl import load_workbook
import fsspec
from openpyxl.utils.dataframe import dataframe_to_rows

path = r'F:\Python\conv_export\xlsx4\output3.xlsx'

df_CRDEV = pd.read_excel(r'F:\Python\conv_export\xlsx4\output3.xlsx', sheet_name='CRDEV', dtype = str)
df_QA2 = pd.read_excel(r'F:\Python\conv_export\xlsx4\output3.xlsx', sheet_name='QA2', dtype = str)

writer = pd.ExcelWriter(path, engine='openpyxl', mode='a')
#df_CRDEV.to_excel(writer, sheet_name='CRDEV', index = False)
#df_QA2.to_excel(writer, sheet_name='QA2', index = False)

#df_CRDEV = pd.read_excel(r'F:\Python\conv_export\xlsx4\CRDEV_EXPORT_DOWNLOAD.xlsx')
#df_QA2 = pd.read_excel(r'F:\Python\conv_export\xlsx4\QA2_EXPORT_DOWNLOAD.xlsx')

comparevalues = df_CRDEV.values == df_QA2.values

#print(comparevalues)

rows,cols = np.where(comparevalues==False)
for item in zip(rows,cols):
    df_CRDEV.iloc[item[0],item[1]] = '{} --> {} '.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])   

rows,cols = np.where(comparevalues==True)
for item in zip(rows,cols):
    df_CRDEV.iloc[item[0],item[1]] = 'TRUE'.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])

#df_CRDEV.to_excel(r'F:\Python\conv_export\xlsx4\output2.xlsx', index=False, header=True)

wb = load_workbook(path)
ws = wb.create_sheet('Compare')
if 'Compare' in wb.sheetnames: #to check whether sheet you need already exists
    ws = wb['Compare']
else:
    ws = wb.active
for r in dataframe_to_rows(df_CRDEV, index=False, header=True):
    ws.append(r)
wb.save(path)

