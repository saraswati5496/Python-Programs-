
"""
# Python code to extract last two digits of a number
#a = 23457
a = input("enter num: ")
a_string = str(a)
a_length = len(a_string)
c = int(a_string[a_length - 2: a_length])
print("The last two digit for the number: ", a, " is: ", c)
"""

# Python code to extract last two digits of a number using Classes

class Last_2_Digit_class(object):
    def last_2_digits(self, number):
        a_string = str(number)
        a_length = len(a_string)
        c = a_string[a_length - 2: a_length]
        return int(c)

a = 6560234

#Create an Object
last_2 = Last_2_Digit_class()

#Call the function using Object
print("Last 2 digit for number: ", a, " is: ", last_2.last_2_digits(a))