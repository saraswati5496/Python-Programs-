class Account:

   def __init__(self, name, balance=0):

       self.name = name

       self.balance = balance

   def __add__(self,acc):

       if isinstance(acc,Account):

           return self.balance  + acc.balance
       else: 
           print("value is: " +self.balance)
       raise Exception(f"{acc} is not of class Account")
  
obj2 = Account("sam", 78)
obj4 = Account("john", 8)

"""
obj3 = add("abc",2)
print(obj3)
"""
#print(obj2.name)
#print(obj4.balance)

print(obj4+obj2)