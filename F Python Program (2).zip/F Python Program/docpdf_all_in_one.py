"""
## converting .doc file to .pdf with using password (Password : olivia)
from comtypes.client import CreateObject
import os 
#folder = (r'C:\Users\rajiv.kandu\Training\Python_test\Data\107')
folder = (r'F:\Python\Conversion\CAR')
wdToPDF = CreateObject("Word.Application")
wdFormatPDF = 17
files = os.listdir(folder)
word_files = [f for f in files if f.endswith((".doc", ".docx"))]
for word_file in word_files:
    word_path = os.path.join(folder, word_file)
    pdf_path = word_path
    #str = " "
    if pdf_path[-3:] != 'pdf':
        #pdf_path = str +".pdf"
        pdf_path = pdf_path + ".pdf"
        #pdf_path2=pdf_path.replace(".doc", ".pdf")
    if os.path.exists(pdf_path):
        os.remove(pdf_path)
    
    pdfCreate = wdToPDF.Documents.Open(word_path, False, True, None, 'olivia')
    ##pdfCreate = Documents.Open(word_path, False, True, None, False)
    pdf_path2=pdf_path.replace(".doc", " ")
    pdfCreate.SaveAs(pdf_path2, wdFormatPDF)

"""

"""
## converting specific .docx to .pdf file 
from docx2pdf import convert

Paths = "C:\Python\wdoc22.docx"
Paths2 = "C:\Python\wpdf22.pdf"
try:
    readfile = open(Paths,"r")
    convert(Paths, Paths2)
    print("successfully converted")

except FileNotFoundError as err:
    print("The file is not exist", err)    

"""
