"""
import aspose.words as aw

# Load word document
#paths = 'F:\\Python\\Conversion\\107'
doc = aw.Document("F:\\Python\\Conversion\\107")


# Create save options and set compliance
saveOptions = aw.saving.PdfSaveOptions()
saveOptions.compliance = aw.saving.PdfCompliance.PDF17 

# Save as PDF
doc.save("PDF.pdf", saveOptions)
"""

wq = [[11,72,13,14],['abc', 'eeeee', 'xxxx'], ['qqq',7234,'yyy']]
zz = [1,2,3,4]
for x in wq:
    #print(x[0])
    print(" ")
    print(x[1])

    #print('zz is: ', zz[1])