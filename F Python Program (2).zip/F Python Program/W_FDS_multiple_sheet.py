from xml.sax import xmlreader
import os
import cx_Oracle
import pandas as pd
import numpy as np
#pip install pandas, numpy, cx_Oracle, openpyxl, xlsxwriter

#                           uname/psswd@hostname             :port/Servicename
conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1') #CRDEV
conn1 = cx_Oracle.connect('rqbi/rqbi@agii-oraql04.argous.com:1528/R3RQBIQAPDB5.argogroupus.com') #QA2 connection
conn2 = cx_Oracle.connect('rqbi/rqbi@agii-oratrnl01.argous.com:1528/rqbitrnpdb2.argogroupus.com') #TRN connection

connection = [[conn,'CRDEV_EXPORT_DOWNLOAD.xlsx'],[conn1,'QA2_EXPORT_DOWNLOAD.xlsx'],[conn2,'TRN_EXPORT_DOWNLOAD.xlsx']]

for x in connection:
  sql_query = pd.read_sql_query("""select distinct tf.form_number, tf.form_number||'-'||tfar.form_edition "FormNumber-Edition",tfe.eff_with_rateset_release,tfrb.business_unit_code,
  decode ((select count(*) from tbli_form_edition tfe1 where tf.form_id = tfe1.form_id and tfe1.eff_with_rateset_release in (select rateset_release_id from tbl_rateset_release where effective_date < TO_DATE('01/JAN/2022','dd/mon/yyyy'))), '0','Yes','No') "New Form?"
  from tbli_form tf, tbli_form_edition tfe,tbli_form_attachment_rule tfar, tbli_form_rule_bus_unit_xref tfrb
  where tf.form_id = tfe.form_id
  and tfe.form_edition = tfar.form_edition
  and tf.form_id = tfar.form_id
  and tfar.form_rule_id = tfrb.form_rule_id
  and tfe.eff_with_rateset_release in (select rateset_release_id from tbl_rateset_release where effective_date >= TO_DATE('01/JAN/2022','dd/mon/yyyy'))
  ---and tfrb.business_unit_code = '121'
  order by 1""",x[0])

  #for .xlsx file export from oracle  
  f = sql_query.to_excel(r'F:\\Python\\conv_export\\fds_export\\fds_export2\\'+x[1], index= False)
  sql_query=""


#for .csv file export from oracle
#sql_query.to_csv(r'C:\Users\rajiv.kandu\Training\Python_test\Data_export\QA2_EXPORT_DOWNLOAD.csv',index= False) 
  #f = sql_query.to_csv(r'F:\\Python\\conv_export\\csv\\'+x[1], index= False) 
  #sql_query=""
#F:\\Python\\conv_export\\fds_export\\fds_export2\\
fileList = os.listdir(r"F:/Python/conv_export/fds_export/fds_export2/")
excelWriter = pd.ExcelWriter(r"F:/Python/conv_export/fds_export/fds_export2/multiple.xlsx",engine='xlsxwriter')
files = [file.split('.',1)[0] for file in fileList]

for file in files:
    df = pd.read_excel('F:/Python/conv_export/fds_export/fds_export2/' +file+ ".xlsx")
    #df.to_excel(excelWriter, sheet_name=file, index = False)
    #file.replace("_EXPORT_DOWNLOAD", "")  
    df.to_excel(excelWriter, sheet_name=file.replace("_EXPORT_DOWNLOAD",""), index= False)
    #df.compare(excelWriter)
excelWriter.save()



"""
import re
abc = "askhnl#$%askdjalsdk"
ddd = abc.replace("#$%","")
print (ddd)
"""
