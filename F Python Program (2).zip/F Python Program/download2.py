import cx_Oracle
import numpy as np
import pandas as pd
con = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
cursor = con.cursor()

tblnm = 'tbli_form_edition'
#sql_string = """SELECT FORM_EDITION||'.pdf', PDF_SAMPLE  FROM tbli_form_edition where FORM_ID'42'"""
for i in range(len(tblnm)):
    sql_string = """SELECT FORM_EDITION||'.pdf', PDF_SAMPLE  FROM tbli_form_edition where FORM_ID='42'"""
#sql_string = """SELECT FORM_EDITION||'.pdf', PDF_SAMPLE  FROM tbli_form_edition where FORM_ID='44'"""
cursor.execute(sql_string)
#Path="C:\Pdffiles"
rows = cursor.fetchall()

for row in rows:
    blobdata = np.array(row[1].read())
    #cursor.close()
    filename = str(row[0]) + ".pdf"
con.close()
f = open(filename, 'wb')
binary_format = bytearray(blobdata)
f.write(binary_format)
f.close()
