#code to read xslt file from oracle database using python

import cx_Oracle

conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')


def download_nclob_file(file_id):
    try:
        cursor = conn.cursor()
        #cursor.execute("SELECT file_data FROM nclob_table WHERE file_id = :file_id", {'file_id': file_id})
        cursor.execute("SELECT XSL_FO FROM tbli_form_template_version WHERE form_template_id = :file_id", {'file_id': file_id})
        nclob_data = cursor.fetchone()[0]
        cursor.close()
        
        print(nclob_data)
        #with open('file.txt', 'w', encoding='utf-8') as f:
        #    f.write(nclob_data.read())
            
    except Exception as e:
        print("Error:", e)
    finally:
        conn.close()

download_nclob_file(7)

#select * from tbli_form_template_version where form_template_id='21304';