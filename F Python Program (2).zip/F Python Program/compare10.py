import pandas as pd
import re
# Creating a DataFrame
DataSample= [[10,'value1'], 
             [20,'value2'], 
             [30,'value3']]
SimpleDataFrame=pd.DataFrame(data=DataSample, columns=['Col1','Col2'])
print(SimpleDataFrame)
 
# Exporting data frame to a csv/Excel file
# Many other options are available which can be seen using dot tab option
 
# Exporting data as a csv file
#SimpleDataFrame.to_csv(r'F:\Python\conv_export\generatexml.xlsx')
 
# Exporting data as a excel file
SimpleDataFrame.to_excel(r'F:\Python\conv_export\generatexml.xlsx')