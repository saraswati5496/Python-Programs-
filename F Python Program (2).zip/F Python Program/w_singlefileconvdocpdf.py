

#convert single file .doc to .pdf
import os
import aspose.words as aw

#doc = aw.Document("sample.doc")
#doc.save("sample.pdf")

"""
p='F:\\Python\\Conversion\\107\\CYS2175-0819.doc'
doc = aw.Document(p)
doc.save('F:\\Python\\Conversion\\107\\CYS2175-0819.pdf')
"""

p2 = open('F:\Python\Conversion\107','r')
pr = p2.read()
print(pr)
