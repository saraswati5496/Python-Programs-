from jinja2 import Template

name = input("Enter your name: ")

tm = Template("Hello {{ name }}")
msg = tm.render(name=name)

print(msg)

person = {'num': 22, 'year' : 2022}
#num = input("enter num: ")
#year = input("enter year: ")

tm = Template("num is {{ per.num }} and year is {{ per.year }} " )
#tm2 = Template("year: {{ year }}")
#msg = tm.render(per = person)
print(tm.render(per = person))
#print(tm2.render( year=year))

person = { 'name': 'Person', 'record': 2 }

tm = Template("your name is {{ per.name }} and I am {{ per.age }} ")
# tm = Template("My name is {{ per['name'] }} and I am {{ per['age'] }}")
msg = tm.render(per=person)

print(msg)

cars = [
    {'name': 'Audi', 'price': 23000}, 
    {'name': 'Skoda', 'price': 17300}, 
    {'name': 'Volvo', 'price': 44300}, 
    {'name': 'Volkswagen', 'price': 21300}
]

print({{ cars | sum(attribute='price') }})



