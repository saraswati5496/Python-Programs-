import xlwings as xw
import pandas as pd

def main():
    #wb = xw.Book.caller()
    wb = xw.Book.caller("F:\Python\Conversion\107")
    
    #ws = wb.sheets["Engine"]
    ws = wb.sheets["F:\Python\Conversion\107"]

    wbs = xw.Book(ws["F:\Python\Conversion\107"].value, read_only=True)
    #wb_rs = xw.Book(ws["s"].value, read_only=True)

    dfRDiners = wbs.sheets["Invoice-Retail-Email"]["C1:H1000"].options(pd.DataFrame, index=False, header=False).value 

    



    