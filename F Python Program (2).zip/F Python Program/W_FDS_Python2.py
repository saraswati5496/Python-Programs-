#Code to export the given oracle database query data into excel format

from xml.sax import xmlreader
import os
import cx_Oracle
import pandas as pd
import numpy as np
#pip install pandas, numpy, cx_Oracle, openpyxl, xlsxwriter

#                           uname/psswd@hostname             :port/Servicename
conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1') #CRDEV
conn1 = cx_Oracle.connect('rqbi/rqbi@agii-oraql04.argous.com:1528/R3RQBIQAPDB5.argogroupus.com') #QA2 connection
conn2 = cx_Oracle.connect('rqbi/rqbi@agii-oratrnl01.argous.com:1528/rqbitrnpdb2.argogroupus.com') #TRN connection
#
#conn3 = cx_Oracle.connect('rqbi/rqbi@agii-oradl02:1528/CRDEVPDB1_TR_PR')#NEW_CRDEV_TR_PR

#conn4 = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/RQBIF21PDB1')#CR_BR_UAT agii-oradl02.argous.com

#conn5 = cx_Oracle.connect('rqbi/rqbi@agii-orasl01:1528/ARGOPLSTPDB1')#DCE-SIT

#conn6 = cx_Oracle.connect('rqbi/rqbi@agii-oradl02:1528/CRRMDEVPDB1')#CRRM_NEW

connection = [[conn,'CRDEV_EXPORT_DOWNLOAD.xlsx'],[conn1,'QA2_EXPORT_DOWNLOAD.xlsx'],[conn2,'TRN_EXPORT_DOWNLOAD.xlsx']]
#connection = [[conn3,'TR_PR_EXPORT_DOWNLOAD.xlsx'],[conn4,'CR_BR_UAT_EXPORT_DOWNLOAD.xlsx'],[conn5,'DCE-SIT_EXPORT_DOWNLOAD.xlsx'],[conn6,'CRRM_NEW_EXPORT_DOWNLOAD.xlsx']]
#connection = [[conn5,'DCE-SIT_EXPORT_DOWNLOAD.xlsx'],[conn4,'CR_BR_UAT_EXPORT_DOWNLOAD.xlsx']]
for x in connection:
  sql_query = pd.read_sql_query("""SELECT 
  TF.FORM_ID,
  nvl(TFAR.SORT_ORDER_OVERRIDE,Tf.SORT_ORDER) as SortOrder,
  TFT.FORM_TEMPLATE_ID,
  TFAR.FORM_RULE_ID RULEID,
  TFT.DESCRIPTION, TFAR.ATTACHMENT_ROLE,  
  TFTV.XSL_FO_FILENAME,
  TF.FORM_NUMBER AS FORM_NUMBER,   
  TFAR.FORM_EDITION "Edition", 
  TFRS.EFF_WITH_RATESET_RELEASE AS "Eff Release", 
  TFRS.EXP_WITH_RATESET_RELEASE AS "Exp Release State", 
  TFAR.EXP_WITH_RATESET_RELEASE AS "Exp Release_rule" , 
  TF.FORM_NUMBER || '-' || TFAR.FORM_EDITION FORMNOEDITION,  
  nvl(TFE.FORM_NAME_OVERRIDE,tf.form_name) AS "Form Title",
  TFG.DESCRIPTION AS "Form Group",
  DECODE(nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID),'21','Common Forms','23','Commercial General Liability Forms','26','Employment Practices Liability Forms','22','Property Forms','24','Internet Liability Forms','25','Professional Liability E&'||'O Forms','28','Umbrella Forms','33','Insured Letters','34','Miscellaneous Letters','35','Parent / Guardian Letters','36','Plaintiff Attorney Letters','37','Front / Especificação','38','Cláusulas','39','Cotação','40','Certificados','41','Cosseguro','42','Resseguro','43','Financeiro','44','Sinistro','48','Quote','101','Terrorism Notice','30','State Amendatory','31','Endorsement','120','Garage Common Forms','125','Garage Mandatory Forms','130','Garage Optional Coverages','135','Garage Property','0','Selection/Rejection forms','0.5','IDs Forms','0.6','KY Tax','1','Jacket','2','Common Declarations','3','Schedule of Forms and Endorsements','4','Coverage Declarations','5','Schedule of Covered Autos','6','Coverage Forms','7','Coverage Form Second','8','Other Forms and Endorsements','9','Coverage form associated with specify which  coverage.  “Associated” forms are forms that modify that coverage.','10','Other','11','Policy Support Documents','0.8','Notice','32','Claimant Letters','50.5','Terrorism','140','Declarations','145','Additional Endorsements','150','Signature Page','155','Cyber Suite','0.4','Application Forms','29','State Forms','50','Policy Common Forms','51','General Liability - Commercial','52','Liquor Liability','53','Property - Commercial','54','Crime - Commercial','55','Inland Marine - Commercial','56','Accounts Receivable','57','Bailees Customers','58','Computer Systems','59','Contractors Equipment','60','Installation','61','Miscellaneous Articles','62','Valuable Papers and Records','63','Farm and Ranch','64','Owners and Contractors Protective','65','Employment Practices Liability','66','State Specific','1.1','Policy Jacket','2.1','E&'||'O Declarations','48.3','Additional Coverage Endorsement','44.4','Class Specific Endorsement','44.5','Correction Endorsement','44.6','Exclusion Endorsement','44.3','Extended Reporting','44.1','Insured','44.2','Cover Sheet','48.1','Binder','48.2','Coverage Endorsement','160','E&'||'O Quote','161','E&'||'O Notices','2.2','Declarations Page',nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID)) AS "Rule Level Form Group", 
  --DECODE(nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID),'10','Other','51','General Liability - Commercial','63','Farm and Ranch','64','Owners and Contractors Protective','2.2','Declarations Page','3','Schedule of Forms and Endorsements','44.6','Exclusion Endorsement','44.3','Extended Reporting','21','Common Forms','31','Endorsement','0.6','KY Tax','6','Coverage Forms','11','Policy Support Documents','0.8','Notice','150','Signature Page','29','State Forms','2.1','E&'||'O Declarations','44.5','Correction Endorsement','161','E&'||'O Notices',nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID)) AS "Rule Level Form Group", 
  nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID) Form_group_id,
  TFAR.GENERATION_TYPE AS "Generate Type", 
  rqbi.wm_concat(distinct(TFRS.STATE_ABBR))  "States",
  rqbi.wm_concat(DISTINCT TFRTT.TRANSACTION_TYPE_ID) "List for these transactions",
  rqbi.wm_concat(DISTINCT(DECODE((TFRTT.TRANSACTION_TYPE_ID ||'-'|| TFRTT.DISPLAY_ON_SCHEDULE_OF_FORMS),'1-1','1','2-1','2','3-1','3','4-1','4','5-1','5','6-1','6','7-1','7','8-1','8','9-1','9','10-1','10','11-1','11','12-1','12','13-1','13','14-1','14','15-1','15','16-1','16','17-1','17','18-1','18','19-1','19','20-1','20','21-1','21','22-1','22','23-1','23','24-1','24','')))  "DISPLAY_ON_SCHEDULE_OF_FORMS", 
  rqbi.wm_concat(DISTINCT(DECODE((TFRTT.TRANSACTION_TYPE_ID ||'-'|| TFRTT.PRINT_WITH_OUTPUT),'1-1','1','2-1','2','3-1','3','4-1','4','5-1','5','6-1','6','7-1','7','8-1','8','9-1','9','10-1','10','11-1','11','12-1','12','13-1','13','14-1','14','15-1','15','16-1','16','17-1','17','18-1','18','19-1','19','20-1','20','21-1','21','22-1','22','23-1','23','24-1','24','')))  "Print to PDF transactions",  
  TST.SELECTION_TYPE_NAME AS "Default Selectiontype",  
  TO_CHAR(TFRBUX.BUSINESS_UNIT_CODE) BUSINESSUNIT,   
  rqbi.wm_concat(DISTINCT(DECODE(TCC.COMPANY_NAME,'Argonaut Insurance Company','AIC','Argonaut Midwest Insurance Company','AMIC','Colony Insurance Company','CIC','Colony Specialty Insurance Company','CSIC','Colony National Insurance Company','CNIC',TCC.COMPANY_NAME))) "Companies",  
  DBMS_LOB.SUBSTR(TFAR.ADDITIONAL_CONDITIONS,4000,1) "Additional Condition",
  tfar.description, 
  rqbi.wm_concat(DISTINCT(DECODE(TFT.TEMPLATE_TYPE_ID,'1','Data Form', '3','Static Form','4','Editable PDF', '6','On Demand Form --> Brazil','7','On Demand Form --> Claim', TFT.TEMPLATE_TYPE_ID))) "Template Type", 
  CASE NVL(TFAR.CAN_BE_DUPLICATED,TF.CAN_BE_DUPLICATED) WHEN 0 THEN'No' WHEN 1 THEN 'Yes' END AS "attach more than one instance",  
  TRR.EFFECTIVE_DATE AS " RuleDate",  
  TRR1.EFFECTIVE_DATE AS  "stateDate",
  --TRR1.EFFECTIVE_DATE AS "STATEDATE",
  EXTRACTVALUE(nvl(tfar.form_attachment_details,tf.FORM_DETAILS), '/propertylist/item[@name=''audience'']/@value') Audience,
  EXTRACTVALUE(nvl(tfar.form_attachment_details,tf.FORM_DETAILS), '/propertylist/item[@name=''grsamplelegalwatermark'']/@value') grsamplelegalwatermark,
  EXTRACTVALUE(nvl(tfar.form_attachment_details,tf.FORM_DETAILS), '/propertylist/item[@name=''removable'']/@value') removable,
  CASE NVL(TFAR.CAN_BE_DUPLICATED,TF.CAN_BE_DUPLICATED) WHEN 0 THEN'No' WHEN 1 THEN 'Yes' END AS "attach more than one instance",  
  case (select count(*) from rqbi.tbli_validation_group tvg, rqbi.tbli_validation_group_form_xr tvgfr where tvg.group_id = tvgfr.group_id and tvg.type_id = '1' and tvgfr.form_id = tf.form_id and tvg.business_unit = tfrbux.BUSINESS_UNIT_CODE) WHEN 0 THEN 'No' ELSE (select rqbi.wm_concat(distinct tvg.group_id) from rqbi.tbli_validation_group tvg, rqbi.tbli_validation_group_form_xr tvgfr where tvg.group_id = tvgfr.group_id and type_id = '1' and tvgfr.form_id = tf.form_id and tvg.business_unit = tfrbux.BUSINESS_UNIT_CODE) END MutuallyExclusive,
  case (select count(*) from rqbi.tbli_validation_group tvg, rqbi.tbli_validation_group_form_xr tvgfr where tvg.group_id = tvgfr.group_id and tvg.type_id = '3' and tvgfr.form_id = tf.form_id  and tvg.business_unit = tfrbux.BUSINESS_UNIT_CODE) WHEN 0 THEN 'No' ELSE (select rqbi.wm_concat(distinct tvg.group_id) from rqbi.tbli_validation_group tvg, rqbi.tbli_validation_group_form_xr tvgfr where tvg.group_id = tvgfr.group_id and type_id = '3' and tvgfr.form_id = tf.form_id and tvg.business_unit = tfrbux.BUSINESS_UNIT_CODE) END OneMustAttach,
  --case (select count(*) from tbli_form_template_var_xref tftvx, tbl_all_variables tav where tftvx.form_template_id = tft.form_template_id and tftvx.variable_id = tav.variable_id) WHEN 0 THEN 'No' ELSE (select wm_concat(tav.name) from tbli_form_template_var_xref tftvx, tbl_all_variables tav where tftvx.form_template_id = tft.form_template_id and tftvx.variable_id = tav.variable_id order by ordinal) END Variables
  DBMS_LOB.SUBSTR(case (select count(*) from rqbi.tbli_form_template_var_xref tftvx, rqbi.tbl_all_variables tav where tftvx.form_template_id = tft.form_template_id and TFT.TEMPLATE_TYPE_ID = '1' and tftvx.variable_id = tav.variable_id and tav.xpath like '%missing_document_data%') WHEN 0 THEN 'No' ELSE (select LISTAGG(tftvx.ordinal ||'-'|| tav.name,', ') WITHIN GROUP (ORDER BY tftvx.ordinal) from rqbi.tbli_form_template_var_xref tftvx, rqbi.tbl_all_variables tav where tftvx.form_template_id = tft.form_template_id and TFT.TEMPLATE_TYPE_ID = '1' and tftvx.variable_id = tav.variable_id and tav.xpath like '%missing_document_data%') END,4000,1) Variables
  --DBMS_OPEN(tftv.richtext_doc) --,tftv.pdf,tfe.pdf_sample
--DBMS_LOB.SUBSTR(case (select count(*) from tbli_form_template_var_xref tftvx, tbl_all_variables tav where tftvx.form_template_id = tft.form_template_id and TFT.TEMPLATE_TYPE_ID = '1' and tftvx.variable_id = tav.variable_id and tav.xpath like '%missing_document_data%') WHEN 0 THEN 'No' ELSE (select LISTAGG(tftvx.ordinal ||'-'|| tav.name,', ') WITHIN GROUP (ORDER BY tftvx.ordinal) from tbli_form_template_var_xref tftvx, tbl_all_variables tav where tftvx.form_template_id = tft.form_template_id and tftvx.variable_id = tav.variable_id and tav.xpath like '%missing_document_data%') END,4000,1)

FROM RQBI.TBLI_FORM_ATTACHMENT_RULE TFAR,  
  RQBI.TBLI_FORM_EDITION TFE, 
  RQBI.TBLI_FORM_RULE_TEMPLATE_XREF TFRT,  
  RQBI.TBLI_FORM TF,  
  RQBI.TBLI_FORM_RULE_BUS_UNIT_XREF TFRBUX,  
  RQBI.TBLI_FORM_TEMPLATE TFT,   
  RQBI.TBLI_FORM_TEMPLATE_VERSION TFTV,
  RQBI.TBLI_FORM_RULE_COMPANY_XREF TFRCX,  
  RQBI.TBL_COMPANY_CODE TCC,  
  RQBI.TBLI_FORM_RULE_STATE_XREF TFRS,  
  RQBI.TBLI_FORM_GROUP TFG,  
  RQBI.TBLI_FORM_RULE_TRANS_TYPE_XREF TFRTT,  
  RQBI.TBLI_FORM_RULE_TRANS_TYPE_XREF TFRTT1, 
  RQBI.TBL_RATESET_RELEASE TRR,  
  RQBI.TBL_RATESET_RELEASE TRR1, 
  RQBI.TBLI_SELECTION_TYPE TST  

where  
  TFAR.FORM_RULE_ID = TFRT.FORM_RULE_ID  
  AND TF.FORM_ID = TFAR.FORM_ID   
  AND TF.FORM_ID = TFE.FORM_ID   
  AND TFAR.FORM_EDITION = TFE.FORM_EDITION 
  AND TFRBUX.FORM_RULE_ID = TFAR.FORM_RULE_ID  
  AND TFRT.FORM_TEMPLATE_ID = TFT.FORM_TEMPLATE_ID  
  AND TFTV.FORM_TEMPLATE_ID = TFT.FORM_TEMPLATE_ID 
  AND tftv.version_number =  (SELECT MAX(version_number) FROM rqbi.tbli_form_template_version WHERE form_template_id = tft.form_template_id)  
  AND TFRCX.FORM_RULE_ID = TFAR.FORM_RULE_ID 
  AND TFRS.FORM_RULE_ID = TFAR.FORM_RULE_ID  
  and TFRS.FORM_RULE_ID=TFRT.form_rule_id 
  and TFRS.FORM_RULE_ID=TFRBUX.form_rule_id 
  and TFRS.FORM_RULE_ID=TFRCX.form_rule_id 
  and TFRS.FORM_RULE_ID=TFRTT.form_rule_id 
  and TFRS.FORM_RULE_ID=TFRTT1.form_rule_id 
  and TFRT.FORM_RULE_ID=TFRBUX.form_rule_id 
  and TFRT.FORM_RULE_ID=TFRCX.form_rule_id 
  and TFRT.FORM_RULE_ID=TFRTT.form_rule_id 
  and TFRT.FORM_RULE_ID=TFRTT1.form_rule_id 
  AND TCC.COMPANY_CODE = TFRCX.COMPANY_CODE  
  AND TFAR.STATUS = 'AV'  
  AND TF.FORM_GROUP_ID=TFG.FORM_GROUP_ID  
  AND TFAR.FORM_RULE_ID=TFRTT.FORM_RULE_ID  
  AND TFAR.FORM_RULE_ID=TFRTT1.FORM_RULE_ID 
  AND TFAR.EFF_WITH_RATESET_RELEASE = TRR.RATESET_RELEASE_ID  
  AND TFAR.SELECTION_TYPE_ID = TST.SELECTION_TYPE_ID  
  --and TFRBUX.BUSINESS_UNIT_CODE in ('GR')
--and (TFRS.EFF_WITH_RATESET_RELEASE in (4310,4320,4330) or TFRS.Exp_WITH_RATESET_RELEASE in (4310,4320,4330))
  and TFRBUX.BUSINESS_UNIT_CODE in ('GR')
--and (TFRS.EFF_WITH_RATESET_RELEASE in (2248,2249,2250) or TFRS.Exp_WITH_RATESET_RELEASE in (2248,2249,2250))
  --and UPPER(TF.FORM_NUMBER) IN ('G1504','G1504CT','G1504IL','G1504NJ','G1504PA','G1504TX','G1504VA','G1504WA','G1517','G1517KS','G1517NH','G1556','G1708','G1715','G1721','G1722','G1723','G1724','G1737','G1739','G1740','G1744','G1745','G1748','G3058','GT7002')
  --and UPPER(TF.FORM_NUMBER) IN ('MPRO-5036','MPRO-4036','MPRO-5050','MPRO-4030','MPRO-4035','MPRO-5038','MPRO-4038','MPRO-4032','MPRO-4022','MPRO-5022','MPRO-4023','MPRO-4024','MPRO-5027','MPRO-4027','MPRO-5031','MPRO-4031','MPRO-4033','MPRO-5034','MPRO-4034','MPRO-4003','MPRO-5102','MPRO-5131','MPRO-5129','MPRO-5134','MPRO-5133','MPRO-5013','MPRO-5040','MPRO-5142','MPRO-5128','MPRO-5125','MPRO-5124','MPRO-5120','MPRO-5121','MPRO-5138','MPRO-5047','MPRO-5137','MPRO-5048','MPRO-5046','MPRO-5141','MPRO-5127','MPRO-5043','PRMP1000DEC','PRMP1000DEC','PRMP1000DECNC','PRMP1000DECOK','PRMP1000DECMT','PRMP1000DECNJ','PRMP1000DECKS','PRMP1000DECKY','PRMP1000','PRMP1000','MPHS','MP-APP142','MP-SUP190','MPRO-5114','MPRO-5111','MPRO-5023')
  --and upper(TF.FORM_NUMBER) IN('CA0107','CA0107','CA0109','CA0109','CA0113','CA0117','CA0117','CA0119','CA0119','CA0123','CA0123','CA0125','CA0125','CA0126','CA0129','CA0129','CA0132','CA0132','CA0134','CA0134','CA0135','CA0135','CA0136','CA0136','CA0137','CA0137','CA0138','CA0138','CA0139','CA0139','CA0144','CA0144','CA0146','CA0146','CA0149','CA0149','CA0160','CA0160','CA0161','CA0161','CA0162','CA0162','CA0166','CA0166','CA0167','CA0172','CA0175','CA0175','CA0183','CA0183','CA0184','CA0184','CA0185','CA0185','CA0188','CA0188','CA0189','CA0190','CA0203','CA0203','CA0204','CA0218','CA0218','CA0220','CA0220','CA0225','CA0240','CA0240','CA0240','CA0240','CA0273','CA0273','CA0301','CA0302','CA0302','CA0302','CA0302','CA0302','CA0302','CA0401','CA0410','CA0413','CA0420','CA0424','CA0425','CA0426','CA0430','CA0431','CA0432','CA0433','CA0437','CA0440','CA0448','CA2001','CA2001','CA2001','CA2018','CA2039','CA2042','CA2045','CA2048','CA2048','CA2054','CA2054','CA2055','CA2055','CA2071','CA2098','CA2103','CA2104','CA2106','CA2107','CA2107','CA2109','CA2111','CA2112','CA2115','CA2116','CA2121','CA2123','CA2124','CA2125','CA2126','CA2127','CA2128','CA2129','CA2131','CA2132','CA2134','CA2135','CA2136','CA2137','CA2138','CA2139','CA2140','CA2145','CA2146','CA2146','CA2148','CA2154','CA2155','CA2156','CA2158','CA2159','CA2161','CA2165','CA2167','CA2168','CA2170','CA2174','CA2176','CA2180','CA2181','CA2182','CA2183','CA2186','CA2187','CA2191','CA2192','CA2193','CA2194','CA2195','CA2196','CA2202','CA2214','CA2216','CA2222','CA2231','CA2232','CA2234','CA2235','CA2237','CA2238','CA2244','CA2246','CA2249','CA2256','CA2257','CA2259','CA2260','CA2263','CA2264','CA2301','CA2301','CA2304','CA2304','CA2305','CA2305','CA2309','CA2310','CA2311','CA2312','CA2317','CA2317','CA2322','CA2326','CA2386','CA2386','CA2392','CA2394','CA2394','CA2395','CA2396','CA2402','CA2402','CA3101','CA3102','CA3103','CA3105','CA3107','CA3108','CA3113','CA3114','CA3115','CA3117','CA3125','CA3127','CA3129','CA3134','CA3136','CA3137','CA9901','CA9910','CA9910','CA9910','CA9910','CA9911','CA9916','CA9916','CA9916','CA9916','CA9917','CA9917','CA9917','CA9923','CA9923','CA9923','CA9923','CA9923','CA9924','CA9928','CA9928','CA9928','CA9928','CA9928','CA9933','CA9933','CA9934','CA9934','CA9939','CA9944','CA9947','CA9947','CA9947','CA9947','CA9952','CA9954','CA9954','CA9962','CA9963','CA9966','CA9968','CA9969','CA9971','CA9981','CA9987','CA9988','CA9989','CA9990','CA9990','CA9990','CA9990','CA9995','CT108','CT108','CT108','CT108IL','CT108NH','CT108NY','CT108TX','CT2105','CT2105','CT2107','CT2108VA','CT2113VA','CT3003NY','CT3054WY','CT3054WY','CT3058','CT3058','CT3058','CT3301','CT3301','CT3301','CT3301','CT3301VA','CT3526NY','CT3558','CT3558','CT3558','CT3558','CT3567','CT3567','CT3567KY','CT3567LTD','CT3567LTDMD','CT3567MI','CT3567WA','CT3576','CT3576','CT3576','CT3580','CT3580','CT3580','CT3580SD','CT3589','CT3589','CT3620','CT3620','CT3620','CT3620','CT3620','CT3620','CT3624','CT3660','CT3660','CT3660','CT3660','CT3680','CT3680','CT3680','CT3680A','CT3680VA','CT3792','CT3792','CT3792','CT3792IL','CT3819','CT3819','CT3819MT','CT4000','CT4000','CT4000','CT4000','CT4001','CT4001','CT4001','CT4003','CT4004','CT4004','CT4004ME','CT4005','CT4005','CT4005NY','CT4005TX','CT4006','CT4008','CT4008','CT4008','CT4009','CT4009','CT4009','CT4010','DCJ2000','GT3598','GT3598','GT3598','GT3598','GT3598','GT3598','GT7000','GT7002','GT7002','GT7003MN','GT7004FL','IL0003','IL0003','IL0003','IL0003','IL0003','IL0003','IL0021','IL0102','IL0104','IL0106','IL0109','IL0109','IL0110','IL0110','IL0111','IL0114','IL0114','IL0115','IL0117','IL0119','IL0120','IL0139','IL0140','IL0140','IL0141','IL0141','IL0142','IL0142','IL0146','IL0147','IL0152','IL0152','IL0153','IL0153','IL0156','IL0158','IL0158','IL0159','IL0161','IL0162','IL0162','IL0163','IL0163','IL0164','IL0165','IL0165','IL0167','IL0167','IL0169','IL0169','IL0170','IL0170','IL0172','IL0175','IL0175','IL0177','IL0178','IL0179','IL0179','IL0183','IL0183','IL0184','IL0184','IL0185','IL0187','IL0187','IL0189','IL0189','IL0198','IL0204','IL0204','IL0208','IL0208','IL0219','IL0219','IL0228','IL0228','IL0231','IL0231','IL0232','IL0232','IL0234','IL0236','IL0236','IL0243','IL0244','IL0244','IL0245','IL0246','IL0246','IL0247','IL0247','IL0249','IL0249','IL0250','IL0250','IL0251','IL0251','IL0252','IL0252','IL0255','IL0255','IL0258','IL0260','IL0261','IL0262','IL0262','IL0263','IL0263','IL0266','IL0266','IL0268','IL0269','IL0269','IL0272','IL0272','IL0273','IL0276','IL0276','IL0277','IL0279','IL0279','IL0286','IL0286','IL0298','IL0909','IL0909','IL0910','IL0910','IL0913','IL0913','IL0935','IL0983','NCUM/UIMNOTICE','NOAZ','NOOR','NOOR','NOVAC','NOWIA','NOWIA','NYSUPPDEC','PA0205','PA0205','PA0216','PA0235','SRMO','SRNM','U094','UCA0112','UCA0112','UCA0120','UCA0143','UCA0165','UCA0165','UCA0215','UCA0230','UCA2105','UCA2114','UCA2122','UCA2130','UCA2157','UCA2163','UCA2236','UCM0107')
   --and upper(TF.FORM_NUMBER) IN('CA2231')
  --and TFAR.FORM_EDITION in('1009','0313')
  --and (upper(TFAR.DESCRIPTION) like '%FLEX%' or upper(TFAR.DESCRIPTION) like '%SQUISH#473%' or upper(TFAR.DESCRIPTION) like '%IC3#SQUISH383%' or upper(TFAR.DESCRIPTION) like '%IC5%' )
  and TFRS.Exp_WITH_RATESET_RELEASE is  null
  --and EXTRACTVALUE(nvl(tfar.form_attachment_details,tf.FORM_DETAILS), '/propertylist/item[@name=''grsamplelegalwatermark'']/@value') is not null
  --and nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID) != '0'
  --and tfrs.state_abbr = 'NH'
  --AND TFTV.XSL_FO_FILENAME in('')
  --and TFTV.xsl_fo like '%gt7002_non_listed_driver%'
  --and UPPER(tf.form_number) in ('CAR1501')
   --and UPPER(TF.form_number) like 'U9%'
  --and tfar.description like '%Flex%'
  --and tfar.generation_type = 'QUOTE'
  --and TFT.TEMPLATE_TYPE_ID not in (1,3,4,6,2)
  --and tfar.additional_conditions like '%GR_P%' 
  --and tfar.additional_conditions not like '%coverage_name%'
    --and tfar.form_rule_id in (14689)
  --and nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID) in(6)
  --and tfar.form_attachment_details is not null
  --and tft.FORM_TEMPLATE_ID in('14689')
  AND TFRS.EFF_WITH_RATESET_RELEASE = TRR1.RATESET_RELEASE_ID  
  AND TFRS.EFF_WITH_RATESET_RELEASE = TRR1.RATESET_RELEASE_ID  


GROUP BY  
  TFAR.FORM_GROUP_ID, 
  TF.FORM_ID, 
  TFT.FORM_TEMPLATE_ID, 
  TFT.DESCRIPTION, TFTV.XSL_FO_FILENAME,
  TFAR.FORM_RULE_ID,  
  TF.FORM_NUMBER,TFAR.FORM_EDITION, 
  TFRS.EFF_WITH_RATESET_RELEASE, 
  TFRS.EXP_WITH_RATESET_RELEASE , 
  TFAR.EXP_WITH_RATESET_RELEASE, 
  TFRBUX.BUSINESS_UNIT_CODE, 
  nvl(TFAR.FORM_GROUP_ID,TF.FORM_GROUP_ID),
  TFAR.GENERATION_TYPE, 
  TFAR.SELECTION_TYPE_ID, 
  DBMS_LOB.SUBSTR(TFAR.ADDITIONAL_CONDITIONS,4000,1),
  tfar.description, 
  TF.FORM_NAME, 
  TFE.FORM_NAME_OVERRIDE, 
  TFG.DESCRIPTION, 
  TFAR.GENERATION_TYPE, 
  TFT.TEMPLATE_TYPE_ID , 
  TRR.EFFECTIVE_DATE, 
  TST.SELECTION_TYPE_NAME, 
  TF.CAN_BE_DUPLICATED , 
  TFAR.CAN_BE_DUPLICATED, TFAR.ATTACHMENT_ROLE,
  TFAR.EFF_WITH_RATESET_RELEASE ,  
  TFRS.EFF_WITH_RATESET_RELEASE ,  
  TRR1.EFFECTIVE_DATE ,TFAR.SORT_ORDER_OVERRIDE,Tf.SORT_ORDER,TF.FORM_GROUP_ID,EXTRACTVALUE(nvl(tfar.form_attachment_details,tf.FORM_DETAILS), '/propertylist/item[@name=''audience'']/@value'),
  EXTRACTVALUE(nvl(tfar.form_attachment_details,tf.FORM_DETAILS), '/propertylist/item[@name=''grsamplelegalwatermark'']/@value'),
  EXTRACTVALUE(nvl(tfar.form_attachment_details,tf.FORM_DETAILS), '/propertylist/item[@name=''removable'']/@value')--,tftv.richtext_doc,tftv.pdf,tfe.pdf_sample
--  wm_concat(tvg.group_id)

ORDER BY  tf.form_number,tfar.eff_with_rateset_release""",x[0] )

  #for .xlsx file export from oracle  
  #f = sql_query.to_excel(r'F:\Python\conv_export\\fds_export\\'+x[1], index= False)
  f = sql_query.to_excel(r'F:\\Python\\conv_export\\fds_export\\fds_export2\\'+x[1], index= False)
  sql_query=""


#for .csv file export from oracle
#sql_query.to_csv(r'C:\Users\rajiv.kandu\Training\Python_test\Data_export\QA2_EXPORT_DOWNLOAD.csv',index= False) 
  #f = sql_query.to_csv(r'F:\\Python\\conv_export\\csv\\'+x[1], index= False) 
  #sql_query=""

fileList = os.listdir(r"F:/Python/conv_export/fds_export/")
excelWriter = pd.ExcelWriter(r"F:/Python/new_export2.xlsx",engine='xlsxwriter')
files = [file.split('.',1)[0] for file in fileList]

for file in files:
    df = pd.read_excel('F:/Python/conv_export/fds_export/'+file+".xlsx")
    #df.to_excel(excelWriter, sheet_name=file, index = False)
    #file.replace("_EXPORT_DOWNLOAD", "")  
    df.to_excel(excelWriter, sheet_name=file.replace("_EXPORT_DOWNLOAD",""), index= False)
    #df.compare(excelWriter)
excelWriter.save()

