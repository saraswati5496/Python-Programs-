import random
print(random.__name__)
print(__name__)