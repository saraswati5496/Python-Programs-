import os
#path = "F:\Python\BU_NotNull\BR_03"
paths = "F:\Python\BU_NotNull\BR_02"

"""
for i in range(1,11):
    os.chdir(paths)
    newfolder = 'BR_03'+str(i)
    os.makedirs(newfolder)
    #to make folder inside the other folders
    path2 = paths+'\\'+newfolder
    os.chdir(path2)
    for j in range(1,3):
        #newfolder2 = 'Test'+str(j)
        newfolder2 = 'BR_03'
        os.makedirs(newfolder2)
"""
"""
os.chdir(paths)
newfolder = 'BR_03'
os.makedirs(newfolder)
#to make folder inside the other folders
path2 = paths+'\\'+newfolder
os.chdir(path2)
for j in range(1,3):
    #newfolder2 = 'Test'
    newfolder2 = 'BR_04'
    os.makedirs(newfolder2)

"""
os.chdir(paths)
newfolder = input("Enter folder name: ")
os.makedirs(newfolder)
#to make folder inside the other folders
path2 = paths+'\\'+newfolder
 
"""os.chdir(path2)
    #newfolder2 = 'Test'
    newfolder2 = 'BR_03'
    os.makedirs(newfolder2)
"""