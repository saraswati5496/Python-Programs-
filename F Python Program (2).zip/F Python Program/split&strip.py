#Using a combination of .split() and .lstrip() methods, get the word "Derivatives".


str="......Macroeconomics,...........Derivatives"
#Type your code here.

lst=str.split(",")
ans_1=lst[1].lstrip(".")

print(ans_1)
