
while True:
    data = input("Please enter a loud message (must all be in caps ): ")
    
    if not data.isupper():
        print("Sorry your response was not loud enough ")
        continue
    else:
        break

while True:
    data = input("Pick an answer from A to D : ")
    if data.lower() not in ('a','b','c','d'):
        print("Not an appropriate choice ")
    else:
        break


   
