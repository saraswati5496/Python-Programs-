# draw any polygon in turtle
# import turtle
import turtle
 
# function to draw
# colored Star
def create_color_star():
    
    # size of Star
    sigeOfStar = 100
    
    # Assign colour to the edges.
    turtle.color("pink")
    
    # Set the width
    turtle.width(4)
    
    # Give angle to form Star
    assine_angle = 120
    
    # Fill the colour as of your choice.
    turtle.fillcolor("violet")
    turtle.begin_fill()
    
    # Create a Star
    for side in range(5):
        turtle.forward(sigeOfStar)
        turtle.right( assine_angle)
        turtle.forward(sigeOfStar)
        turtle.right(72 -  assine_angle)
        
    # fill color
    turtle.end_fill()
 
# Driver code
create_color_star()
