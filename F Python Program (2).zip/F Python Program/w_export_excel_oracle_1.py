#Code to export oracle database query data in excel sheet format.

import cx_Oracle
import pandas as pd

conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')

sql_query = pd.read_sql_query("""select distinct tf.form_number, tf.form_number||'-'||tfar.form_edition "FormNumber-Edition",tfe.eff_with_rateset_release,tfrb.business_unit_code,
decode ((select count(*) from tbli_form_edition tfe1 where tf.form_id = tfe1.form_id and tfe1.eff_with_rateset_release in (select rateset_release_id from tbl_rateset_release where effective_date < TO_DATE('01/JAN/2022','dd/mon/yyyy'))), '0','Yes','No') "New Form?"
from tbli_form tf, tbli_form_edition tfe,tbli_form_attachment_rule tfar, tbli_form_rule_bus_unit_xref tfrb
where tf.form_id = tfe.form_id
and tfe.form_edition = tfar.form_edition
and tf.form_id = tfar.form_id
and tfar.form_rule_id = tfrb.form_rule_id
and tfe.eff_with_rateset_release in (select rateset_release_id from tbl_rateset_release where effective_date >= TO_DATE('01/JAN/2022','dd/mon/yyyy'))
---and tfrb.business_unit_code = '121'
order by 1""",conn)

#for .xlsx file export from oracle
# sql_query.to_excel(r'C:\Users\rajiv.kandu\Training\Python_test\Data_export\EXPORT_DOWNLOAD.xlsx',index= False) 
sql_query.to_excel(r'F:\Python\conv_export\xlsx\new_xlsx2.xlsx',index=False)
#for .csv file export from oracle
#sql_query.to_csv(r'C:\Users\rajiv.kandu\Training\Python_test\Data_export\EXPORT_DOWNLOAD1.csv',index= False) 
