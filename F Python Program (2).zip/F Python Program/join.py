lst=["Hawaii", "Phuket", "Aruba", "Keys"]

#Type your answer here.

joined= ",".join(lst)

print(joined)