from comtypes.client import CreateObject
import os 
folder = (r'F:\Python\conv_all\G1504s fixed typo')         #doc to pdf conversion
#folder = (r'F:\Python\newdocx')
#folder = (r'F:\Python\Conversion\107')
wdToPDF = CreateObject("Word.Application")
wdFormatPDF = 17
files = os.listdir(folder)
word_files = [f for f in files if f.endswith((".doc", ".docx"))]
for word_file in word_files:
    word_path = os.path.join(folder, word_file)
    pdf_path = word_path
    #str = " "
    if pdf_path[-3:] != 'pdf':
        #pdf_path = str +".pdf"
        pdf_path = pdf_path + ".pdf"
        #pdf_path2=pdf_path.replace(".doc", ".pdf")
    if os.path.exists(pdf_path):
        os.remove(pdf_path)
    
    
    #pdfCreate = wdToPDF.Documents.Open(word_path, False, True, None, 'olivia')
    pdfCreate = wdToPDF.Documents.Open(word_path, True, True, None, 'olivia')
    ##pdfCreate = Documents.Open(word_path, False, True, None, False)
    pdf_path2=pdf_path.replace(".doc", " ")
    pdfCreate.SaveAs(pdf_path2, wdFormatPDF)

   # pdf_path3 = pdf_path.replace("x", "")
   # pdfCreate.SaveAs(pdf_path2, wdFormatPDF)
#121, 123, IM, GR, BR_01, BR_02, BR_03
#101, 103, 164, 600, 600EX, 103EX, 121, 123, 107, IM, GR, TR, CAR, BR_01,BR_02,BR_03

