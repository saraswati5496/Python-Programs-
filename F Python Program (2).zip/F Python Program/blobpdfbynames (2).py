from pathlib import Path
import cx_Oracle
import numpy as np
import pandas as pd
import os
import shutil
con = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
cursor = con.cursor()
BU = input("Enter Business Unit: ")
print(BU)
BU_list = ['107', 'IM', 'GR', 'TR', 'CAR', 'BR_01', 'BR_02', 'BR_03']
     
sql_string = """select a.filename,tftv.richtext_doc,tftv.form_template_id from (
select distinct tf.form_number||'-'||tfar.form_edition||'.doc' filename,max(tfar.form_rule_id),max(tfrtx.form_template_id) templ_id from tbli_form tf, tbli_form_attachment_rule tfar, tbli_form_rule_template_xref tfrtx, tbli_form_rule_bus_unit_xref tfrb
where tf.form_id = tfar.form_id
--and tfar.form_rule_id = max(tfar.form_rule_id)
and tfar.form_rule_id= tfrtx.form_rule_id
and tfar.form_rule_id= tfrb.form_rule_id
and tfrb.business_unit_code=:BUs
--{'id': (user_value)})
and tfar.exp_with_rateset_release is not null
group by tf.form_number,tfar.form_edition
order by 3) a, tbli_form_template_version tftv
where a.templ_id = tftv.form_template_id
and tftv.richtext_doc is not null
order by 1""";

cursor.execute(sql_string, {'BUs':BU})
#query = "select * from some_table where col=:my_param"
#cursor.execute(query, {'my_param': 5})
rows = cursor.fetchall()

"""
paths = 'F:\\Python\\NewBU\\'        
os.chdir(paths)
newfolder = input("Enter folder name: ")
os.makedirs(newfolder)
#to make folder inside the other folders
path2 = paths+'\\'+newfolder
"""

try:
    paths = 'W:\\Sarasw\\Python\\NewBU'       
    os.chdir(paths)
    #newfolder = input("Enter folder name: ")
    os.makedirs(BU)
    #to make folder inside the other folders
    path2 = paths+'\\'+BU+'\\'
except FileExistsError as err:
    print("already exists", err)

    
for row in rows:
    #blobdata= np.array(row[1].read())
    filename =str(row[0])

    #f = open(path2 +filename, "r")
    blobdata= np.array(row[1].read())
    #f = os.path.join(path2, filename)
    f = open(path2 +filename, "w+b")
    
    binary_format = bytearray(blobdata)
    f.write(binary_format)
    f.close()    
      
cursor.close()
con.close()