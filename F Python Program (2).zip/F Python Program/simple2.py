class Account:
    def __init__(self, name, balance):
        self.name = name
        self.balance = balance

    def __new22__(self, acc):
        if isinstance(acc, Account):
            return self.balance  + acc.balance

        raise Exception(f"{acc} is not of class Account")

acc1 = Account("sam", 1000)
acc2 = Account("john", 5000)

print(acc1+acc2)

print(acc1.name)
print(acc2.balance)
