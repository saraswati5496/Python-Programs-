
name=input("Please enter your name.")
#Type your answer here.
str="Hello!, {}".format(name)

 
print(str)