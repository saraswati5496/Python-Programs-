from openpyxl import load_workbook
import pandas as pd
import numpy as np
import os
import re

df1 = pd.read_excel("C:/Users/rajiv.kandu/Training/Python_test/Data_export/Multiple_sheet.xlsx", sheet_name='CRDEV', dtype = str)
df2 = pd.read_excel("C:/Users/rajiv.kandu/Training/Python_test/Data_export/Multiple_sheet.xlsx", sheet_name='QA2', dtype = str)
df1.fillna( '',inplace=True)
df2.fillna( '',inplace=True)

array1 = np.array(df1)
array2 = np.array(df2)

df_CRDEV = pd.DataFrame(array1, columns=['FORM_ID',    'SORTORDER',    'FORM_TEMPLATE_ID',    'RULEID',    'DESCRIPTION',    'ATTACHMENT_ROLE',    'XSL_FO_FILENAME',    'FORM_NUMBER',    'Edition',    'Eff Release'])
df_QA2   = pd.DataFrame(array2, columns=['FORM_ID',    'SORTORDER',    'FORM_TEMPLATE_ID',    'RULEID',    'DESCRIPTION',    'ATTACHMENT_ROLE',    'XSL_FO_FILENAME',    'FORM_NUMBER',    'Edition',    'Eff Release'])

df_CRDEV.index += 1
df_QA2.index += 1

print(df_CRDEV.eq(df_QA2).to_string(index=True))
print("\n")