from docx2pdf import convert

Paths = "C:\Python\wdoc22.docx"
Paths2 = "C:\Python\wpdf22.pdf"
try:
    readfile = open(Paths,"r")
    convert(Paths, Paths2)
    print("successfully converted")

except FileNotFoundError as err:
    print("The file is not exist", err)    



