import os
#import win32com.client
from os import chdir, getcwd, listdir, path
from time import strftime
import win32com.client
import re
import aspose.words
"""
folder = 'F:\Python\Conversion\107'
try:
    word = client.DispatchEx("Word.Application")
    for files in listdir(getcwd()):
        if files.endswith(".docx"):
            new_name = files.replace(".docx", r".pdf")
            in_file = path.abspath(folder + "\\" + files)
            new_file = path.abspath(folder + "\\" + new_name)
            doc = word.Documents.Open(in_file)
            print(strftime("%H:%M:%S"), " docx -> pdf ", path.relpath(new_file))
            doc.SaveAs(new_file, FileFormat = 17)
            doc.Close()
        if files.endswith(".doc"):
            new_name = files.replace(".doc", r".pdf")
            in_file = path.abspath(folder + "\\" + files)
            new_file = path.abspath(folder + "\\" + new_name)
            doc = word.Documents.Open(in_file)
            print(strftime("%H:%M:%S"), " doc  -> pdf ", path.relpath(new_file)) 
            doc.SaveAs(new_file, FileFormat = 17)
            doc.Close()
except Exception as e:
    print(e)
finally:
    word.Quit()
"""  

path = (r'F:\Python\Conversion\107')
word_file_names = []
word = win32com.client.Dispatch('Word.Application')
for dirpath, dirnames, filenames in os.walk(path):
    for f in filenames:               
        if f.lower().endswith(".doc"):
            new_name = f.replace(".doc", ".pdf")
            in_file =(dirpath +'/' + f)
            new_file =(dirpath +'/' + new_name)
            doc = word.Documents.Open(in_file)           
            doc.save(new_file, FileFormat = 17)
            doc.Close()
word.Quit()    

