import cx_Oracle

cx_Connector = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
try:
    with cx_Connector as co:
        print("Connected")
        cur=co.cursor()
        """
        cur.execute("SELECT * FROM CodeSpeed")
        x=cur.fetchone()
        print(x)
        cur.execute("SELECT * FROM CodeSpeed")
        y=cur.fetchmany(2)
        print(y)
        """
        cur.execute("SELECT * FROM tbli_form_edition where form_id=2")
        z=cur.fetchall()
        print(z)
        
        print("Data Fetched")
        cur.close()
                
except Exception as e:
    print("Error: ",str(e))