from openpyxl import load_workbook
from xml.sax import xmlreader
import pandas as pd
import numpy as np
import xlsxwriter
import os
import re
import fsspec
from openpyxl.utils.dataframe import dataframe_to_rows


df_CRDEV = pd.read_excel(r'F:\Python\conv_export\xlsx4\CRDEV_EXPORT_DOWNLOAD.xlsx')
df_QA2 = pd.read_excel(r'F:\Python\conv_export\xlsx4\QA2_EXPORT_DOWNLOAD.xlsx')

comparevalues = df_CRDEV.values == df_QA2.values

df2 = print(comparevalues)

with pd.ExcelWriter(r'F:\Python\conv_export\xlsx4\output.xlsx') as writer:
    df2.to_excel(writer, sheet_name='CRDEV', index = False)
    df2.to_excel(writer, sheet_name='QA2', index= False)

#df2.to_excel(r'F:\Python\conv_export\xlsx4\output.xlsx', index = False)

rows,cols = np.where(comparevalues==False)

for item in zip(rows,cols):
    df_CRDEV.iloc[item[0],item[1]] = '{} --> {} '.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])

    df_CRDEV.to_excel(r'F:\Python\conv_export\xlsx4\output.xlsx', index=False, header=True)