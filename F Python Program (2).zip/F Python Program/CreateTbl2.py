

#conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')

#import cx_Oracle

# establishg connection
#connection = cx_Oracle.connect(
#   user="rqbi", 
#    password="rqbi",
#    dsn="@agii-oradl02.argous.com:1528/CRDEVPDB1")

import cx_Oracle
cx_connector = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
try:
    with cx_connector as co:
        print("Connected")
        cur=co.cursor()
        cur.execute('''CREATE TABLE
                        CodeSpeed(employee_id number(10),employee_name varchar2(10))''')
        print("Table Created")
        
        cur.close()
                
except Exception as e:
    print("Error: ",str(e))
    