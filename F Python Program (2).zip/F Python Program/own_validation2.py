
def get_non_negative_int(prompt):
    while True:
        try: 
            value = int(input(prompt))
        except ValueError:
            print("invalid input, I did'nt understand it")
            continue
        if value < 0:
            print("value must not be negative ")
            continue
        else:
            print("value is acceptable")
            break
        #return value

kids = get_non_negative_int("enter your age: ")
employee = get_non_negative_int("enter your salary: ")
person = get_non_negative_int("enter your number: ")



    
