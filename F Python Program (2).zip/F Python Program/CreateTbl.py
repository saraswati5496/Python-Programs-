#run this command in terminal
#pip install cx_Oracle

#code for creating table in oracle using python

import cx_Oracle
try:
  #create connection
  conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
  print(conn.version)

  #create cursor
  cur = conn.cursor()

  sql_create = """
  create table Elect(
   electnm varchar2(50),
   electcity varchar2(50),
   electrole varchar2(50)
  )
  """

  cur.execute(sql_create)
  print('Table created')

except Exception as err:
  print("Unable to connect Error:{Str(err)}")

finally:
  cur.close()
  conn.close()  
