import pandas as pd
import numpy
import cx_Oracle

df = pd.DataFrame()

conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1') #CRDEV
cursor = conn.cursor()
cursor.execute(""" select * from rqbi.tbli_form_template_version where form_template_id in (17413,17414,17425,21142,21143,21141,21332) order by form_template_id desc """)

#select * from rqbi.tbli_form_template_version where  form_template_id in (17413,17414,17425,21142,21143,21141,21332) order by form_template_id desc;

for row in cursor:
  # row[0] = COURSE_NUMB
  # row[1] = COURSE_DESCRIPTION - note the call to "read()" on the CLOB
  df_tmp = pd.DataFrame([[row[0], row[1].read()]],
                        columns=["FORM_TEMPLATE_ID", "LAST_MODIFIED_BY"])
  df = df.append(df_tmp, ignore_index=True)

print ("***Before conn.close()")
print(df.head(1))
conn.close()
print ("\n***After conn.close()")
print(df.head())