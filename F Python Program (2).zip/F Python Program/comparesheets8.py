import pandas as pd
import numpy as np
import os 
import re
from openpyxl import load_workbook
# pip install openpyxl, pandas, numpy

df1 = pd.read_excel(r'F:/Python/conv_export/xlsx/multiple_sheet.xlsx', sheet_name='CRDEV', dtype = str)
df2 = pd.read_excel(r'F:/Python/conv_export/xlsx/multiple_sheet.xlsx', sheet_name='QA2', dtype = str)
df1.fillna('',inplace=True)
df2.fillna('',inplace=True)

array1 = np.array(df1)
array2 = np.array(df2)

#df_CRDEV = pd.DataFrame(array1, columns=['FORM_ID',    'SORTORDER',    'FORM_TEMPLATE_ID',    'RULEID',    'DESCRIPTION',    'ATTACHMENT_ROLE',    'XSL_FO_FILENAME',    'FORM_NUMBER',    'Edition',    'Eff Release'])
#df_QA2   = pd.DataFrame(array2, columns=['FORM_ID',    'SORTORDER',    'FORM_TEMPLATE_ID',    'RULEID',    'DESCRIPTION',    'ATTACHMENT_ROLE',    'XSL_FO_FILENAME',    'FORM_NUMBER',    'Edition',    'Eff Release'])


df_CRDEV = pd.DataFrame(array1, columns=['FORM_ID',	'SORTORDER',	'FORM_TEMPLATE_ID',	'RULEID',	'DESCRIPTION',	'ATTACHMENT_ROLE',	'XSL_FO_FILENAME',	'FORM_NUMBER',	'Edition',	'Eff Release'])
df_QA2   = pd.DataFrame(array2, columns=['FORM_ID',	'SORTORDER',	'FORM_TEMPLATE_ID',	'RULEID',	'DESCRIPTION',	'ATTACHMENT_ROLE',	'XSL_FO_FILENAME',	'FORM_NUMBER',	'Edition',	'Eff Release'])

df_CRDEV.index += 1
df_QA2.index += 1

print(df_CRDEV.eq(df_QA2).to_string(index=True))
print("\n")

#z = df_CRDEV.eq(df_QA2).to_string(index=True)
#z.to_excel(r'F:\Python\conv_export\generatexml2.xlsx')


#writer = pd.ExcelWriter(r'F:\Python\conv_export\xlsx\multiple_sheet.xlsx')
#df2.to_excel(writer, sheet_name='Sheet1', index = False)
#writer.save()

df2 = df_CRDEV.eq(df_QA2) 
#.to_string(index=True)
df2.to_excel(r'F:/Python/conv_export/xlsx2/multiple_sheet.xlsx', sheet_name='Sheet1', index = False)

"""
 Creating a DataFrame
DataSample= [[10,'value1'], 
             [20,'value2'], 
             [30,'value3']]
#SimpleDataFrame=pd.DataFrame(data=DataSample, columns=['Col1','Col2'])
#print(SimpleDataFrame)
 """
# Exporting data frame to a csv/Excel file
# Many other options are available which can be seen using dot tab option
 
# Exporting data as a csv file
## df2.to_csv(r'F:\Python\conv_export\xlsx2\multiple_sheet.xlsx')
 
# Exporting data as a excel file
##SimpleDataFrame.to_excel(r'F:\Python\conv_export\xlsx2\multiple_sheet.xlsx', sheet_name='Sheet2', index = False)

#for foo in root.finadall(xpath):
   #    print (foo.name[xpath], foo.country[xpath])
   #    df = DataFrame({'Name': foo.name[xpath], 'conutry': foo.country[xpath]})
  #     df.to_excel('foo.xlsx', sheet_name='sheet1', index=False)







