
#code for comparing and showing differences for different excel sheets.. it will create excel sheet and will show difference in that 

import pandas as pd
import numpy as np
from openpyxl import load_workbook
import fsspec
from openpyxl.utils.dataframe import dataframe_to_rows

path = r'F:\Python\conv_export\fds_export\multiple_sheet2.xlsx'

#df_CRDEV = pd.read_excel(path, sheet_name='CRDEV', dtype = str)
df_QA2 = pd.read_excel(path, sheet_name='QA2', dtype = str)
df_TRN = pd.read_excel(path, sheet_name='TRN', dtype= str)
#df_QA2.fillna('', inplace=True)
#df_TRN.fillna('', inplace=True)

writer = pd.ExcelWriter(path, engine='openpyxl', mode='a')

##check if value in index row 1 of column 'points' is empty
print(pd.isnull(df_QA2.loc[7, 'XSL_FO_FILENAME']))
print(pd.isnull(df_TRN.loc[7, 'XSL_FO_FILENAME']))
##True

#comparevalues = df_CRDEV.values == df_QA2.values
comparevalues = df_QA2.values == df_TRN.values
#df_QA2.fillna('', inplace=True)
#df_TRN.fillna('', inplace=True)



print(comparevalues)

rows,cols = np.where(comparevalues==False)
for item in zip(rows,cols):
    #df_CRDEV.iloc[item[0],item[1]] = '{} --> {} '.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])   
    df_QA2.iloc[item[0],item[1]] = '{} --> {} '.format(df_QA2.iloc[item[0], item[1]], df_TRN.iloc[item[0],item[1]]) 
    if df_QA2.iloc[item[0],item[1]] == 'nan --> nan ':
        df_QA2.iloc[item[0],item[1]] = 'TRUE'

rows,cols = np.where(comparevalues==True)
for item in zip(rows,cols):
    #df_CRDEV.iloc[item[0],item[1]] = 'TRUE'.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])
    df_QA2.iloc[item[0],item[1]] = 'TRUE'.format(df_QA2.iloc[item[0], item[1]], df_TRN.iloc[item[0],item[1]])
#df_CRDEV.to_excel(r'F:\Python\conv_export\xlsx4\output2.xlsx', index=False, header=True)


wb = load_workbook(path)
ws = wb.create_sheet('Compare')
if 'Compare' in wb.sheetnames: #to check whether sheet you need already exists
    ws = wb['Compare']
else:
    ws = wb.active
for r in dataframe_to_rows(df_QA2, index=False, header=True):
    ws.append(r)
wb.save(path)



