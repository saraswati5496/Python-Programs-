import pandas as pd
import numpy as np
import os
import re
from xlsxwriter import Workbook

fileList = os.listdir(r"F:/Python/conv_export/xlsx/")
excelWriter = pd.ExcelWriter(r'F:/Python/conv_export/xlsx/multiple_sheet.xlsx', engine="xlsxwriter")
files = [file.split('.',1)[0] for file in fileList]

for file in files:
    df = pd.read_excel(r'F:/Python/conv_export/xlsx/'+file+".xlsx")
    #df.to_excel(excelWriter, sheet_name=file, index = False)
    #file.replace("_EXPORT_DOWNLOAD", "")  
    df2=df.to_excel(excelWriter, sheet_name=file.replace("_EXPORT_DOWNLOAD",""), index= False)
    #df.compare(excelWriter)
    print(df.equals(df2))
excelWriter.save()

#workbook = Workbook(r'F:/Python/conv_export/xlsx/multiple_sheet.xlsx', engine="xlsxwriter")
#worksheet = workbook.add_worksheet('Summary')
#Workbook.close()

"""
rows, cols = np.where(comparison_values == False)
for item in zip(rows,cols):
    df1.iloc[item[0], item[1]] = '{} --> {}'.format(df1.iloc[item[0], item[1]], df2.iloc[item[0], item[1]])

df1.to_excel('./Excel_diff.xlsx', index = False, header = True)
""" 

# comparing cells in multiple excel sheets formula =AND(TRN!A2='QA2'!A2,'QA2'!A2=CRDEV!A2)
