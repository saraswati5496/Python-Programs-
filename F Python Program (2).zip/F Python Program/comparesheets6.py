
from openpyxl import load_workbook
import pandas as pd
import numpy as np
import os
import re
#from xlsxwriter import Workbook

fileList = os.listdir(r"F:/Python/conv_export/xlsx/")
excelWriter = pd.ExcelWriter(r'F:/Python/conv_export/xlsx/multiple_sheet.xlsx', engine="xlsxwriter")
files = [file.split('.',1)[0] for file in fileList]

for file in files:
    df = pd.read_excel(r'F:/Python/conv_export/xlsx/'+file+".xlsx")
    #df.to_excel(excelWriter, sheet_name=file, index = False)
    #file.replace("_EXPORT_DOWNLOAD", "")  
    df2=df.to_excel(excelWriter, sheet_name=file.replace("_EXPORT_DOWNLOAD",""), index= False)
    #df.compare(excelWriter)
    #print(df.equals(df2))
excelWriter.save()

#for row in excelWriter.row:
   # print([x.value for x in row])

"""
wb = load_workbook(r'F:/Python/conv_export/xlsx/multiple_sheet.xlsx')
sheet = wb.active
count=0
# Access all cells from A1 to D11
for row in sheet.rows:
    print ([x.value for x in row])
    count= count+1

print(count)
"""

#df.compare(excelWriter)
#print(df.equals(df2))