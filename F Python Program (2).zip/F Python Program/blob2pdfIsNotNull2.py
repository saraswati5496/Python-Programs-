import cx_Oracle
import numpy as np
import pandas as pd
import os




con = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
cursor = con.cursor()
#buCAR = print("Enter Business Unit: ")
sql_string = """select a.filename,tftv.richtext_doc,tftv.form_template_id from (
select distinct tf.form_number||'-'||tfar.form_edition||'.doc' filename,max(tfar.form_rule_id),max(tfrtx.form_template_id) templ_id from tbli_form tf, tbli_form_attachment_rule tfar, tbli_form_rule_template_xref tfrtx, tbli_form_rule_bus_unit_xref tfrb
where tf.form_id = tfar.form_id
--and tfar.form_rule_id = max(tfar.form_rule_id)
and tfar.form_rule_id= tfrtx.form_rule_id
and tfar.form_rule_id= tfrb.form_rule_id
and tfrb.business_unit_code = 'BR_01'
and tfar.exp_with_rateset_release is not null
group by tf.form_number,tfar.form_edition
order by 3) a, tbli_form_template_version tftv
where a.templ_id = tftv.form_template_id
and tftv.richtext_doc is not null
order by 1""";



cursor.execute(sql_string)
rows = cursor.fetchall()



for row in rows:
        blobdata= np.array(row[1].read())
        filename =str(row[0])
        f = open("C:\\Python\\BU_NotNull\\BR_01\\" +filename, "w+b")
        binary_format = bytearray(blobdata)
        f.write(binary_format)
        f.close()
cursor.close()
con.close()