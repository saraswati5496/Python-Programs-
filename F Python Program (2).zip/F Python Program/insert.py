#cx_connector = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')

import cx_Oracle
cx_connector = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')
try:
    with cx_connector as co:
        print("Connected")
        cur=co.cursor()
        
        cur.execute('''INSERT INTO
                       CodeSpeed values(101,'Sam')''')
        cur.execute('''INSERT INTO
                       CodeSpeed values(102,'John')''')
        cur.execute('''INSERT INTO 
                       CodeSpeed values(103,'Ram')''')
        
        
        co.commit()
        cur.close()
        print("Data Inserted")
        
                
except Exception as e:
    print("Error: ",str(e))    
