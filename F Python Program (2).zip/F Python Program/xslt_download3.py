#code to download xslt file from oracle database and save in specific directory
import cx_Oracle
import os 
# Connect to the Oracle database

conn = cx_Oracle.connect('rqbi/rqbi@agii-oradl02.argous.com:1528/CRDEVPDB1')

# Define the query to select the XSLT NCLOB file and its name from the database table
query = 'SELECT XSL_FO, XSL_FO_FILENAME FROM tbli_form_template_version WHERE form_template_id = 7'
 
#SELECT XSL_FO FROM tbli_form_template_version WHERE form_template_id = :file_id
  
# Execute the query
cursor = conn.cursor()
cursor.execute(query)

# Iterate over the query result
for row in cursor:
    # Extract the XSLT NCLOB file and its name
    XSL_FO = row[0].read()
    XSL_FO_FILENAME = row[1]
    
    # Save the XSLT NCLOB file with its respective name to disk   
    #if XSL_FO_FILENAME:
    #    with open(XSL_FO_FILENAME, 'wb') as f:
    #        f.write(XSL_FO.encode('utf-8'))

    if not os.path.exists('xslt_files'):
        os.mkdir('xslt_files')

    if XSL_FO_FILENAME:
        file_path = os.path.join('xslt_files', XSL_FO_FILENAME)
        with open(file_path, 'wb') as f:
            f.write(XSL_FO.encode('utf-8'))   
