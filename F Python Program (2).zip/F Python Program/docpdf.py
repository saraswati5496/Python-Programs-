"""
import sys
import os
#import comtypes.client
import win32com.client

wdFormatPDF = 17

import sys
import os
import comtypes.client

wdFormatPDF = 17

in_file = os.path.abspath('F:\')
out_file = os.path.abspath(sys.argv[2])

word = comtypes.client.CreateObject('Word.Application')
doc = word.Documents.Open(in_file)
doc.SaveAs(out_file, FileFormat=wdFormatPDF)
doc.Close()
word.Quit()
"""
import os
import comtypes.client
format_code =17

#file_input = os.path.abspath('F:/Python_test/Data/BU_107/AKNOTICE-0808.doc')
file_input = os.path.commonpath("C:\Python\Conversion")
file_output = os.path.commonpath("C:\Python\Conversion")
#file_output = os.path.abspath('F:/Python_test/Data/BU_107/AKNOTICE-0808.pdf')
word_app = comtypes.client.CreateObject('Word.Application')
word_file = word_app.Documents.Open(file_input)
word_file.SaveAs(file_output,FileFormat=format_code)
word_file.Close()
word_app.Quit()

