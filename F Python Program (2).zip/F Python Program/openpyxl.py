from openpyxl import load_workbook

writer = pd.ExcelWriter(path, engine= 'openpyxl')
writer.book = book


df3.to_excel(writer, sheet_name='x3')
writer.close()

mode='a'