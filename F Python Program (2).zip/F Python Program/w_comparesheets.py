from openpyxl import load_workbook
from xml.sax import xmlreader
import pandas as pd
import numpy as np
import xlsxwriter
import os
import re
import fsspec

df1 = pd.read_excel(r'F:\Python\conv_export\xlsx\multiple_sheet.xlsx', sheet_name='CRDEV', dtype = str)
df2 = pd.read_excel(r'F:\Python\conv_export\xlsx\multiple_sheet.xlsx', sheet_name='QA2', dtype = str)
df1.fillna( '',inplace=True)
df2.fillna( '',inplace=True)

array1 = np.array(df1)
array2 = np.array(df2)

#FORM_NUMBER	FormNumber-Edition	EFF_WITH_RATESET_RELEASE	BUSINESS_UNIT_CODE	New Form?

df_CRDEV = pd.DataFrame(array1, columns=['FORM_NUMBER',    'FormNumber-Edition',    'EFF_WITH_RATESET_RELEASE',    'BUSINESS_UNIT_CODE',    'New Form?'])
df_QA2   = pd.DataFrame(array2, columns=['FORM_NUMBER',    'FormNumber-Edition',    'EFF_WITH_RATESET_RELEASE',    'BUSINESS_UNIT_CODE',    'New Form?'])

df_CRDEV.index += 1
df_QA2.index += 1

df3 = df_CRDEV.eq(df_QA2)
writer = pd.ExcelWriter(r'F:\Python\conv_export\xlsx\multiple_sheet.xlsx', engine='openpyxl', mode='a') 
# writer.book = book 
# 
df3.to_excel(writer, sheet_name ='Compare', index=False)
# writer.close() 
# df3.to_excel(writer, sheet_name='Compare', index= False)
writer.save()