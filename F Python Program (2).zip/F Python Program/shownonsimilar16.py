#code for comparing and showing differences for different excel sheets.. it will create excel sheet and will show difference in that 


import pandas as pd
import numpy as np
from openpyxl import load_workbook
import fsspec
from openpyxl.utils.dataframe import dataframe_to_rows
import ctypes  # An included library with Python install.   

path = r'F:\Python\conv_export\fds_export\multiple_sheet2.xlsx'

#with open(path, 'w', encoding='utf-8') as f:
   # f.write('comparision is here')

   # Take the filename to check
##filename = input("Enter any existing filename:\n")
# Open the file for the first time using open() function
##fileHandler = open(filename, "r")
# Try to open the file same file again
"""
try:
    with open("filename", "r") as file:
        # Print the success message
        print("File has opened for reading.")
# Raise error if the file is opened before
except IOError:
    print("File has opened already.")
"""
#filepath = open(path, 'w')   
try:
    with open(path, 'r') as file:
        print('file is already open')
        file.close()
except IOError:
    print("File has opened already.")

df_QA2 = pd.read_excel(path, sheet_name='QA2', dtype = str)
df_TRN = pd.read_excel(path, sheet_name='TRN', dtype= str)

writer = pd.ExcelWriter(path, engine='openpyxl', mode='a')

if len(df_QA2) == len(df_TRN):
    df_QA2 = pd.read_excel(path, sheet_name='QA2', dtype = str)

    df_TRN = pd.read_excel(path, sheet_name='TRN', dtype= str)

    writer = pd.ExcelWriter(path, engine='openpyxl', mode='a')
    comparevalues = df_QA2.values == df_TRN.values
 
    print(comparevalues)
    
    rows,cols = np.where(comparevalues==False)
    for item in zip(rows,cols):
        df_QA2.iloc[item[0],item[1]] = '{} --> {} '.format(df_QA2.iloc[item[0], item[1]], df_TRN.iloc[item[0],item[1]])   
        
        if df_QA2.iloc[item[0],item[1]] == 'nan --> nan ':
            df_QA2.iloc[item[0],item[1]] = 'TRUE'
        #if df_CRDEV.iloc[item[0],item[1]] == 'nan --> df_QA2.iloc[item[0],item[1]]'.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]]):
           # df_CRDEV.iloc[item[0],item[1]] = 'FALSE'
    rows,cols = np.where(comparevalues==True)
    for item in zip(rows,cols):
        df_QA2.iloc[item[0],item[1]] = 'TRUE'.format(df_QA2.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])
    
    #df_CRDEV.to_excel(r'F:\Python\conv_export\xlsx4\output2.xlsx', index=False, header=True)

    wb = load_workbook(path)
    ws = wb.create_sheet('Compare')
    if 'Compare' in wb.sheetnames: #to check whether sheet you need already exists
        ws = wb['Compare']
    else:
        ws = wb.active
    for r in dataframe_to_rows(df_QA2, index=False, header=True):
        ws.append(r)
    wb.save(path)
else:
    print("Record count in both excel sheets should be equal")  
    
    ctypes.windll.user32.MessageBoxW(0, "Record count in both excel sheets should be equal", "Your title", 1) 

