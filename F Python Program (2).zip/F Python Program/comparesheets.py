from xml.sax import xmlreader
import os
import cx_Oracle
import pandas as pd
import numpy as np
#pip install pandas, numpy, cx_Oracle, openpyxl, xlsxwriter

fileList = os.listdir(r"F:/Python/conv_export/xlsx/")
excelWriter = pd.ExcelWriter(r"F:/Python/conv_export/xlsx/multiple_sheet.xlsx",engine='xlsxwriter')
files = [file.split('.',1)[0] for file in fileList]

#compare2 =df1.equals(df2)
#print(compare2)

#compare_values = (df1.values == df2.values)
#print(compare_values)

for file in files:
    df = pd.read_excel(r'F:/Python/conv_export/xlsx/'+file+".xlsx")
    df2=pd.to_excel(excelWriter, sheet_name=file, index= False)
    compare = df.equals(df2)
    print(compare)
excelWriter.save()

"""
for file in files:
    df = pd.read_excel('F:/Python/conv_export/xlsx/'+file+".xlsx")
    df2=df.to_excel(excelWriter, sheet_name=file.replace("_EXPORT_DOWNLOAD",""), index= False)
    print(df.equals(df2))
    #print(file.equals())
excelWriter.save()
"""

"""
fileList = os.listdir(r"F:/Python/conv_export/xlsx/")
excelWriter = pd.ExcelWriter(r"F:/Python/conv_export/xlsx/multiple_sheet.xlsx", engine='xlsxwriter')
files = [file.split('.',1)[0] for file in fileList]

for file in files:
    df = pd.read_excel('F:/Python/conv_export/xlsx/'+file+".xlsx")
    #df.to_excel(excelWriter, sheet_name=file, index = False)
    #file.replace("_EXPORT_DOWNLOAD", "")  
    df.to_excel(excelWriter, sheet_name=file.replace("_EXPORT_DOWNLOAD",""), index= False)
    #df.compare(excelWriter)
excelWriter.save()
"""

