while True:
    try:
        userin = int(input("enter input: "))
    except ValueError:
        print("Please enter valid input, I did'nt  understand that")
        continue
    else:
        #print("age successfully parsed")
        break

if userin > 18:
    print("you are eligible for vote in US")
else:
    print("you are not eligible for vote in US")    

