
import pandas as pd
import numpy as np
from openpyxl import load_workbook
import fsspec
from openpyxl.utils.dataframe import dataframe_to_rows
import ctypes  # An included library with Python install.   
import os

path = r'F:\Python\conv_export\fds_export\multiple_sheet2.xlsx'

"""
try:
    fd = os.open(path, os.O_RDONLY)
    s = "GeeksForGeeks: A computer science portal for geeks"
    line = str.encode(s)
    os.write(fd, line)
    os.close(fd)
"""

filepath = open(path, 'r')   
try:
    with open(path, 'r') as file:
        print('file is already open')
        file.close()
        
#except IOError:
   # print("File has opened already.")

    #os.close(fd)
    file.close(path)
    print("..")
    df_QA2 = pd.read_excel(path, sheet_name='QA2', dtype = str)
    
    df_TRN = pd.read_excel(path, sheet_name='TRN', dtype= str)
    
    writer = pd.ExcelWriter(path, engine='openpyxl', mode='a')
    
    if len(df_QA2) == len(df_TRN):
        df_QA2 = pd.read_excel(path, sheet_name='QA2', dtype = str)
    
        df_TRN = pd.read_excel(path, sheet_name='TRN', dtype= str)
    
        writer = pd.ExcelWriter(path, engine='openpyxl', mode='a')
        comparevalues = df_QA2.values == df_TRN.values
     
        print(comparevalues)
        
        rows,cols = np.where(comparevalues==False)
        for item in zip(rows,cols):
            df_QA2.iloc[item[0],item[1]] = '{} --> {} '.format(df_QA2.iloc[item[0], item[1]], df_TRN.iloc[item[0],item[1]])   
            
            if df_QA2.iloc[item[0],item[1]] == 'nan --> nan ':
                df_QA2.iloc[item[0],item[1]] = 'TRUE'
            #if df_CRDEV.iloc[item[0],item[1]] == 'nan --> df_QA2.iloc[item[0],item[1]]'.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]]):
               # df_CRDEV.iloc[item[0],item[1]] = 'FALSE'
        rows,cols = np.where(comparevalues==True)
        for item in zip(rows,cols):
            df_QA2.iloc[item[0],item[1]] = 'TRUE'.format(df_QA2.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])
        
        #df_CRDEV.to_excel(r'F:\Python\conv_export\xlsx4\output2.xlsx', index=False, header=True)
    
        wb = load_workbook(path)
        ws = wb.create_sheet('Compare')
        if 'Compare' in wb.sheetnames: #to check whether sheet you need already exists
            ws = wb['Compare']
        else:
            ws = wb.active
        for r in dataframe_to_rows(df_QA2, index=False, header=True):
            ws.append(r)
        wb.save(path)
    else:
        print("Record count in both excel sheets should be equal")  
        
        ctypes.windll.user32.MessageBoxW(0, "Record count in both excel sheets should be equal", "Your title", 1) 

except IOError as err:
    print("Oops.. close the file")
    file.close()