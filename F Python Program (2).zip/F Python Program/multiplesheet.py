import pandas as pd
import numpy as np
import os
import re
from xml.sax import xmlreader
#r'F:\\Python\\conv_export\\csv\\
fileList = os.listdir(r"F:/Python/conv_export/xlsx/")
excelWriter = pd.ExcelWriter(r"F:/Python/conv_export/xlsx/multiple_sheet.xlsx", engine='xlsxwriter')
files = [file.split('.',1)[0] for file in fileList]

for file in files:
    df = pd.read_excel('F:/Python/conv_export/xlsx/'+file+".xlsx")
    df.to_excel(excelWriter, sheet_name=file, index = False)
excelWriter.save()