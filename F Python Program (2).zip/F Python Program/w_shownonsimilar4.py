
import pandas as pd
import numpy as np
from openpyxl import load_workbook
import fsspec
from openpyxl.utils.dataframe import dataframe_to_rows
import ctypes  # An included library with Python install.   

#path = r'F:\Python\conv_export\justcheck\excel3.xlsx'
path = r'F:\Python\conv_export\fds_export\multiple_sheet1.xlsx'
df_CRDEV = pd.read_excel(path, sheet_name='CRDEV', dtype = str)
df_QA2 = pd.read_excel(path, sheet_name='QA2', dtype = str)

#df_TRN = pd.read_excel(path, sheet_name='TRN', dtype= str)

writer = pd.ExcelWriter(path, engine='openpyxl', mode='a')

try:
    if len(df_CRDEV) == len(df_QA2):
        comparevalues = df_CRDEV.values == df_QA2.values
     
        print(comparevalues)
        
        rows,cols = np.where(comparevalues==False)
        for item in zip(rows,cols):
            df_CRDEV.iloc[item[0],item[1]] = '{} --> {} '.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])   
            
            if df_CRDEV.iloc[item[0],item[1]] == 'nan --> nan ':
                df_CRDEV.iloc[item[0],item[1]] = 'TRUE'
            #if df_CRDEV.iloc[item[0],item[1]] == 'nan --> df_QA2.iloc[item[0],item[1]]'.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]]):
               # df_CRDEV.iloc[item[0],item[1]] = 'FALSE'

        rows,cols = np.where(comparevalues==True)
        for item in zip(rows,cols):
            df_CRDEV.iloc[item[0],item[1]] = 'TRUE'.format(df_CRDEV.iloc[item[0], item[1]], df_QA2.iloc[item[0],item[1]])
        
        #df_CRDEV.to_excel(r'F:\Python\conv_export\xlsx4\output2.xlsx', index=False, header=True)
    
        wb = load_workbook(path)
        ws = wb.create_sheet('Compare')
        if 'Compare' in wb.sheetnames: #to check whether sheet you need already exists
            ws = wb['Compare']
        else:
            ws = wb.active
        for r in dataframe_to_rows(df_CRDEV, index=False, header=True):
            ws.append(r)
        wb.save(path)
    else:
        print("Record count in both excel sheets should be equal")  
        
        ctypes.windll.user32.MessageBoxW(0, "Record count in both excel sheets should be equal", "Your title", 1) 
except Exception as err:
    print(err)
