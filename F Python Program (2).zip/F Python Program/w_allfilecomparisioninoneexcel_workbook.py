from openpyxl import load_workbook
from xml.sax import xmlreader
import pandas as pd
import numpy as np
import xlsxwriter
import os
import re
import fsspec
from openpyxl.utils.dataframe import dataframe_to_rows

df1 = pd.read_excel(r'F:\Python\conv_export\xlsx\multiple_sheet3.xlsx', sheet_name='CRDEV', dtype = str)
df2 = pd.read_excel(r'F:\Python\conv_export\xlsx\multiple_sheet3.xlsx', sheet_name='QA2', dtype = str)
df1.fillna( '',inplace=True)
df2.fillna( '',inplace=True)

array1 = np.array(df1)
array2 = np.array(df2)

#FORM_NUMBER	FormNumber-Edition	EFF_WITH_RATESET_RELEASE	BUSINESS_UNIT_CODE	New Form?

df_CRDEV = pd.DataFrame(array1, columns=['FORM_NUMBER',    'FormNumber-Edition',    'EFF_WITH_RATESET_RELEASE',    'BUSINESS_UNIT_CODE',    'New Form?'])
df_QA2   = pd.DataFrame(array2, columns=['FORM_NUMBER',    'FormNumber-Edition',    'EFF_WITH_RATESET_RELEASE',    'BUSINESS_UNIT_CODE',    'New Form?'])

df_CRDEV.index += 1
df_QA2.index += 1
df3 = df_CRDEV.eq(df_QA2)


path = r'F:\Python\conv_export\xlsx\multiple_sheet3.xlsx'

wb = load_workbook(path)
ws = wb.create_sheet('Compare')
if 'Compare' in wb.sheetnames: #to check whether sheet you need already exists
    ws = wb['Compare']
else:
    ws = wb.active
for r in dataframe_to_rows(df3, index=False, header=True):
    ws.append(r)
wb.save(path)