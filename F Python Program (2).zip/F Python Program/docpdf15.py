import os 
import re
import comtypes.client
input_dir = r"F:\Python\conv_all\IM"

def doc_to_pdf():
    word = comtypes.client.CreateObject('Word.Application')
    doc = word.Documents.Open(input_path)
    doc.SaveAs(output_path, FileFormat=17)
    doc.Close()
    word.Quit()

doc_files = [f for f in os.listdir(input_dir) if f.endswith(".doc")]

for doc_file in doc_files:
    input_path = os.path.join(input_dir, doc_file)
    output_path = os.path.splitext(input_path)[0]+".pdf"
    doc_to_pdf(input_path,output_path)